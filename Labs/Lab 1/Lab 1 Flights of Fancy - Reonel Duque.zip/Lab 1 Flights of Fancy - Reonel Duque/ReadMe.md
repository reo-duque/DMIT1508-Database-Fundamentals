Known bugs:
n/a
Estimate duration of completion of the lab:
3.5 hours